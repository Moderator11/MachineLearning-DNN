﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LearningModel;
using Matrices;

namespace MachineLearning
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] layer = { 2, 10, 10, 2 };
            string[] actf = { "relu", "leakyrelu", "leakyrelu", "sigmoid" };
            LearningModel<double> a = new LearningModel<double>(layer, actf, "MSE");
            Matrix<double> input, output;
            GenerateSampleDate(10, out input, out output);
            a.Initialize_Silent();
            for (int i = 0; i < 1000; i++)
            {
                a.Train_BatchSilent(input, output);
            }
            for (; ; )
            {
                string[] data = Console.ReadLine().Replace(" ", "").Split(',');
                double[,] test = new double[1, data.Length];
                for (int i = 0; i < data.Length; i++)
                {
                    test[0, i] = double.Parse(data[i]);
                }
                a.Predict(new Matrix<double>(test));
            }
            //Test();
        }

        static void GenerateSampleDate(int sampleNumber , out Matrix<double> _coordinates, out Matrix<double> _classification)
        {
            double[,] coordinates = new double[sampleNumber * 2, 2];
            double[,] classification = new double[sampleNumber * 2, 2];
            Random r = new Random();
            for (int i = 0; i < sampleNumber; i++)
            {
                double radius = r.NextDouble();
                double radian = r.NextDouble() * 2 * Math.PI;
                double x = radius * Math.Cos(radian);
                double y = radius * Math.Sin(radian);
                coordinates[i, 0] = x;
                coordinates[i, 1] = y;
                classification[i, 0] = 1;
                classification[i, 1] = 0;
            }
            for (int i = sampleNumber; i < 2 * sampleNumber; i++)
            {
                double radius = 10 * r.NextDouble() + 1;
                double radian = r.NextDouble() * 2 * Math.PI;
                double x = radius * Math.Cos(radian);
                double y = radius * Math.Sin(radian);
                coordinates[i, 0] = x;
                coordinates[i, 1] = y;
                classification[i, 0] = 0;
                classification[i, 1] = 1;
            }
            _coordinates = new Matrix<double>(coordinates);
            _classification = new Matrix<double>(classification);
        }

        static void Test()
        {
            LearningModelTester tester = new LearningModelTester();
            tester.Tester_1();
        }
    }
}