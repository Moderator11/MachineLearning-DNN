﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Matrices;

namespace MachineLearning
{
    class Program
    {
        static void Main(string[] args)
        {
            LearningModel<double> a = new LearningModel<double>(new int[] { 2, 2, 1 });
            a.Initialize();

            Matrix<double> i1 = new Matrix<double>(new double[,] { { 1, 1 } });
            Matrix<double> o1 = new Matrix<double>(new double[,] { { 1 } });

            Matrix<double> i2 = new Matrix<double>(new double[,] { { 0, 0 } });
            Matrix<double> o2 = new Matrix<double>(new double[,] { { 1 } });

            Matrix<double> i3 = new Matrix<double>(new double[,] { { 0, 1 } });
            Matrix<double> o3 = new Matrix<double>(new double[,] { { 0 } });

            Matrix<double> i4 = new Matrix<double>(new double[,] { { 1, 0 } });
            Matrix<double> o4 = new Matrix<double>(new double[,] { { 0 } });

            a.Train(i1, o1);
            //a.Debug();

            /*ConsoleKey key = Console.ReadKey().Key;
            do
            {
                key = Console.ReadKey().Key;
                a.Train(i1, o1);
                a.Train(i2, o2);
                a.Train(i3, o3);
                a.Train(i4, o4);

            } while (key != ConsoleKey.X);*/

            Console.ReadKey();
        }
    }

    class LearningModel<T>
    {
        //https://playground.tensorflow.org/
        //https://developers.google.com/machine-learning/practica/image-classification
        //https://ml-cheatsheet.readthedocs.io/en/latest/forwardpropagation.html

        //https://gomguard.tistory.com/m/182
        //https://cs.stackexchange.com/questions/35266/ann-backpropagation-with-multiple-output-neurons

        //<핵심>
        //https://doomed-lab.tistory.com/41
        //https://wikidocs.net/150781

        int[] layerModel;

        Matrix<T>[] weights;
        Matrix<T>[] biases;
        Matrix<T>[] unitS;//Sum
        Matrix<T>[] unitV;//value
        Matrix<T>[] unitD;//delta

        T mapMax = (T)Convert.ChangeType(1, typeof(T));
        T mapMin = (T)Convert.ChangeType(-1, typeof(T));

        T learningRate = (T)Convert.ChangeType(0.01, typeof(T));

        public LearningModel(int[] _layerModel)
        {
            layerModel = _layerModel;
        }

        public void Initialize()
        {
            int connectionLayerCount = layerModel.Length - 1;
            weights = new Matrix<T>[connectionLayerCount];
            biases = new Matrix<T>[connectionLayerCount];
            unitS = new Matrix<T>[layerModel.Length];
            unitV = new Matrix<T>[layerModel.Length];
            unitD = new Matrix<T>[layerModel.Length];

            for (int i = 0; i < connectionLayerCount; i++)
            {
                weights[i] = new Matrix<T>(layerModel[i], layerModel[i + 1]);
                biases[i] = new Matrix<T>(1, layerModel[i + 1]);
                weights[i].Map(mapMin, mapMax);
                biases[i].Map(mapMin, mapMax);

                Console.WriteLine("\nLayer {0}-{1} weights", i, i + 1);
                Matrix<T>.EnumerateMatrix(weights[i].GetMatrix());
                Console.WriteLine("\nLayer {0} biases", i + 1);
                Matrix<T>.EnumerateMatrix(biases[i].GetMatrix());
            }
            Console.WriteLine();
            for (int i = 0; i < layerModel.Length; i++)
            {
                unitS[i] = new Matrix<T>(1, layerModel[i]);
                unitV[i] = new Matrix<T>(1, layerModel[i]);
                unitD[i] = new Matrix<T>(1, layerModel[i]);
                if (i == 0)
                {
                    Console.WriteLine("InputLayer {0} count = {1}", i, layerModel[i]);
                }
                else if (i == layerModel.Length - 1)
                {
                    Console.WriteLine("OutputLayer {0} count = {1}", i, layerModel[i]);
                }
                else
                {
                    Console.WriteLine("HiddenLayer {0} count = {1}", i, layerModel[i]);
                }
            }
        }

        public void Train(Matrix<T> inputData, Matrix<T> desiredOutputData)
        {
            Console.WriteLine("\nFeeding Forward...");
            for (int i = 0; i < layerModel.Length; i++)
            {
                if (i == 0)//Input Layer
                {
                    unitV[i] = inputData;
                    Console.WriteLine("\nInput");
                    Matrix<T>.EnumerateMatrix(unitV[i].GetMatrix());
                }
                else
                {
                    unitS[i] = (unitV[i - 1] * weights[i - 1]) + biases[i - 1];
                    unitV[i] = unitS[i];
                    Console.WriteLine("\nSum");
                    Matrix<T>.EnumerateMatrix(unitS[i].GetMatrix());
                    unitV[i].ApplyFunction(ActivationFunction);
                    Console.WriteLine("\nValue");
                    Matrix<T>.EnumerateMatrix(unitV[i].GetMatrix());
                    Console.WriteLine("Sum");
                    Matrix<T>.EnumerateMatrix(unitS[i].GetMatrix());
                }
            }
            Console.WriteLine("Feed Forward Output");
            Matrix<T>.EnumerateMatrix(unitV[unitV.Length - 1].GetMatrix());
            Matrix<T> errorTable = unitV[unitV.Length - 1];
            errorTable = (errorTable - desiredOutputData);
            errorTable.ApplyFunction((T x) => x * (dynamic)x);
            Console.WriteLine("Error Found");
            Matrix<T>.EnumerateMatrix(errorTable.GetMatrix());

            for (int i = layerModel.Length - 1; i >= 0; i--)
            {
                if (i == layerModel.Length - 1)//Output Layer
                {
                    //since i indicates last index of each array,
                    Matrix<T> errorDiff = unitV[i];
                    errorDiff = (dynamic)2 * (errorDiff - desiredOutputData);//d error / d output f(z)
                    Matrix<T> actFDiff = unitS[i];
                    actFDiff.ApplyFunction(ActivationFunctionPrime);//d output f(z) / d output z
                    T[,] ed = errorDiff.GetMatrix();
                    T[,] fd = actFDiff.GetMatrix();
                    T[,] outD = new T[ed.GetLength(0), ed.GetLength(1)];
                    for (int j = 0; j < ed.GetLength(0); j++)
                    {
                        for (int k = 0; k < ed.GetLength(1); k++)
                        {
                            outD[j, k] = (dynamic)ed[j, k] * fd[j, k];
                        }
                    }
                    unitD[i] = new Matrix<T>(outD);
                }
                else
                {
                    /*
                    unitD[i] = unitD[i + 1] * weights[i];//This will work only if each layer has same amount of unit
                    Matrix<T> actFDiff = unitS[i];
                    actFDiff.ApplyFunction(ActivationFunctionPrime);
                    unitD[i] = unitD[i] ^ actFDiff;
                    */
                    T[,] foreDelta = unitD[i + 1].GetMatrix();
                    T[,] tempWeight = weights[i].GetMatrix();
                    T[,] tempDelta = new T[tempWeight.GetLength(0), 1];//---------!!!---------assuring input of only one data

                    for (int j = 0; j < tempDelta.GetLength(0); j++)
                    {
                        for (int k = 0; k < layerModel[i + 1]; k++)
                        {
                            tempDelta[j, 0] = (dynamic)tempWeight[j, k] * foreDelta[0, k];//---------!!!---------assuring input of only one data
                        }
                    }

                    unitD[i] = new Matrix<T>(tempDelta);
                    unitD[i].InverseByDiagonalLine();
                    Matrix<T> actFDiff = unitS[i];
                    actFDiff.ApplyFunction(ActivationFunctionPrime);
                    unitD[i] = unitD[i] ^ actFDiff;
                }
            }

            for (int i = 0; i < unitD.Length; i++)
            {
                Console.WriteLine("\nLayer {0} delta", i);
                Matrix<T>.EnumerateMatrix(unitD[i].GetMatrix());
            }

            Console.WriteLine("Backpropagating...");
            for (int i = layerModel.Length - 1; i > 0; i--)
            {
                T[,] tempWeights = weights[i-1].GetMatrix();
                T[,] tempUnitV = unitV[i - 1].GetMatrix();
                T[,] tempDelta = unitD[i].GetMatrix();
                for (int j = 0; j < tempWeights.GetLength(0); j++)
                {
                    for (int k = 0; k < tempWeights.GetLength(1); k++)
                    {
                        tempWeights[j, k] = tempWeights[j, k] - (dynamic)learningRate * tempDelta[0, k] * tempUnitV[0, j];//---------!!!---------assuring input of only one data
                    }
                }
                weights[i - 1] = new Matrix<T>(tempWeights);
            }
            Console.WriteLine("Back Prop Done.");
        }

        public void Debug()
        {
            Console.WriteLine("--------------------<Neural Network Debug Report>--------------------");
            Console.WriteLine("\n1.Pre-described info");
            Console.WriteLine("Mapping Range = {0} ~ {1}", mapMin, mapMax);
            Console.WriteLine("Learning Rate = {0}", learningRate);

            Console.WriteLine("\n2.Pre-designed info");
            Console.WriteLine("LayerCount : {0}", layerModel.Length);
            for (int i = 0; i < layerModel.Length; i++)
            {
                Console.WriteLine("Layer {0} unit count : {1}", i, layerModel[i]);
            }
            for (int i = 0; i < layerModel.Length - 1; i++)
            {
                Console.WriteLine("\nConnectionLayer {0} : L{0}-L{1}", i, i + 1);
                Console.WriteLine("\nWeight");
                Matrix<T>.EnumerateMatrix(weights[i].GetMatrix());
                Console.WriteLine("\nBias");
                Matrix<T>.EnumerateMatrix(biases[i].GetMatrix());
            }

            Console.WriteLine("\n3. Latest train info");
            for (int  i = 0;  i < layerModel.Length;  i++)
            {
                Console.WriteLine("\nLayer {0} train result", i);
                Console.WriteLine("\nunit Sum");
                Matrix<T>.EnumerateMatrix(unitS[i].GetMatrix());
                Console.WriteLine("\nunit Value=func(sum)");
                Matrix<T>.EnumerateMatrix(unitV[i].GetMatrix());
                Console.WriteLine("\nunit Delta");
                Matrix<T>.EnumerateMatrix(unitD[i].GetMatrix());
            }
            Console.WriteLine("--------------------<Neural Network Debug Report>--------------------");
        }

        private T FindError(T x, T y)
        {
            return (x - (dynamic)y) * (x - (dynamic)y);
        }

        private T ErrorFindPrime(T x, T y)
        {
            return 2*(x - (dynamic)y);
        }

        private T ActivationFunction(T x)
        {
            return Sigmoid(x);
        }

        private T ActivationFunctionPrime(T x)
        {
            return SigmoidPrime(x);
        }

        private T Sigmoid(T x) // sigmoid
        {
            return 1 / (1 + Math.Pow(Math.E, -(dynamic)x));
        }

        private T SigmoidPrime(T x) // sigmoid prime
        {
            return Sigmoid(x) * (1 - (dynamic)Sigmoid(x));
        }
    }

    class Tester//Do Tester.RunTest();
    {
        public static void RunTest()
        {
            double learningRate = 0.01f;
            Layer n1 = new Layer(1);
            Layer n2 = new Layer(2, n1);
            Layer n3 = new Layer(1, n2);
            do
            {
                TestCase(new double[] { 0.5f }, new double[] { 0.5f });
            } while (Console.ReadKey().Key == ConsoleKey.Enter);

            void TestCase(double[] data, double[] desiredOut)
            {
                Console.WriteLine("\n-----------------------------------------\n------------<Running TestCase>-----------");
                if (n1.perceptrons.Length == data.Length && n3.perceptrons.Length == desiredOut.Length)
                {
                    for (int i = 0; i < n1.perceptrons.Length; i++)
                    {
                        n1.perceptrons[i].result = data[i];
                    }
                    n2.CalculateLayer();
                    n3.CalculateLayer();

                    Console.WriteLine("\n-----------------------------------------\n------------<Back Propagation>-----------");//only 3n perceptrons
                    for (int i = 0; i < n3.perceptrons.Length; i++)
                    {
                        Console.WriteLine("Output : {0}\nDesired Output : {1}\nCost : {2}", n3.perceptrons[i].result, desiredOut[i], Math.Pow(n3.perceptrons[i].result - desiredOut[i], 2));
                        Console.WriteLine("dcost/dbias={0}", 2 * (n3.perceptrons[i].result - desiredOut[i]) * SigmoidDerivative(n3.perceptrons[i].sumofAll));
                        for (int k = 0; k < n3.perceptrons[i].weights.Length; k++)
                        {
                            double dcdw = 2 * (n3.perceptrons[i].result - desiredOut[i]) * SigmoidDerivative(n3.perceptrons[i].sumofAll) * n2.perceptrons[k].result;
                            Console.WriteLine("dcost/dw{0}={1}", k, dcdw);
                            Console.WriteLine("Applying new weight...");
                            Console.WriteLine("Before weight = {0}", n3.perceptrons[i].weights[k]);
                            n3.perceptrons[i].weights[k] += learningRate * dcdw;
                            Console.WriteLine("After weight = {0}", n3.perceptrons[i].weights[k]);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("There is something wrong with the neural structure.");
                }
                double Sigmoid(double x)
                {
                    return 1 / (1 - Math.Pow(Math.E, -x));
                }
                double SigmoidDerivative(double x)
                {
                    return Sigmoid(x) * (1 - Sigmoid(x));
                }
            }

            Console.ReadKey();
        }
    }

    class Layer
    {
        public static bool implyRandom = true;
        static Random r = new Random();

        public Layer inputLayer;
        public Perceptron[] perceptrons;
        public Layer(int count, Layer inLayer = null)
        {
            perceptrons = new Perceptron[count];
            inputLayer = inLayer;
            for (int i = 0; i < perceptrons.Length; i++)
            {
                if (implyRandom)//imply random
                {
                    double b = r.NextDouble();
                    int pn = r.Next() % 2 == 0 ? 1 : -1;
                    Console.WriteLine("\n<P{0}> is initialized by bias = {1}", i, b);
                    perceptrons[i] = new Perceptron(pn * b, inputLayer);
                }
                else
                {
                    Console.WriteLine("\n<P{0}> is initialized by bias = 0", i);
                    perceptrons[i] = new Perceptron(0, inputLayer);
                }
            }
        }

        public void CalculateLayer()
        {
            Console.WriteLine("\n<Layer Calculation>");
            for (int i = 0; i < perceptrons.Length; i++)
            {
                Console.Write("P{0} = ", i);
                perceptrons[i].Calculate(inputLayer);
            }
        }

        public class Perceptron
        {
            public double bias = 0f;
            public double result = 0f;
            public double[] weights = new double[0];
            public double sumofAll = 0f;//for backpropagation

            public Perceptron(double _bias = 0, Layer inputLayer = null)
            {
                bias = _bias;
                if (inputLayer != null)
                {
                    weights = new double[inputLayer.perceptrons.Length];
                    if (implyRandom)//imply random
                    {
                        for (int i = 0; i < weights.Length; i++)
                        {
                            double w = r.NextDouble();
                            int pn = r.Next() % 2 == 0 ? 1 : -1;
                            weights[i] = pn * w;
                            Console.WriteLine("    weight[{0}] = {1}", i, weights[i]);
                        }
                    }
                }
            }

            public void Calculate(Layer inputLayer)
            {
                double sum = 0;
                for (int i = 0; i < inputLayer.perceptrons.Length; i++)
                {
                    sum += inputLayer.perceptrons[i].result * weights[i];
                }
                sumofAll = sum + bias;
                //Activation Function
                /*if (sum + bias <= 0)
                {
                    result = 0;
                }
                else
                {
                    result = 1;
                }*/
                //Activation Function
                result = 1 / (1 + Math.Pow(Math.E, -(sum + bias)));
                //Activation Function
                Console.WriteLine("{0}", result);
            }
        }
    }
}