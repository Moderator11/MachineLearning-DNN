﻿using System;
using Matrices;

namespace LearningModel//Written by Soomin Park, In 2022-06-30 6:43 pm.
{
    class LearningModel<T>
    {
        //https://playground.tensorflow.org/
        //https://developers.google.com/machine-learning/practica/image-classification
        //https://ml-cheatsheet.readthedocs.io/en/latest/forwardpropagation.html

        //https://gomguard.tistory.com/m/182
        //https://cs.stackexchange.com/questions/35266/ann-backpropagation-with-multiple-output-neurons

        //<핵심>
        //https://doomed-lab.tistory.com/41
        //https://wikidocs.net/150781


        //for future
        //https://visualstudiomagazine.com/articles/2017/08/01/neural-network-momentum.aspx


        string path = Environment.CurrentDirectory + @"\Model-Data.mldat";

        int[] layerModel;

        public Matrix<T>[] weights;
        public Matrix<T>[] biases;
        Matrix<T>[] unitS;//Sum
        Matrix<T>[] unitV;//value
        Matrix<T>[] unitD;//delta

        public T mapMax = (T)Convert.ChangeType(1, typeof(T));
        public T mapMin = (T)Convert.ChangeType(-1, typeof(T));

        public T learningRate = (T)Convert.ChangeType(0.01, typeof(T));

        public LearningModel(int[] _layerModel)
        {
            layerModel = _layerModel;
        }

        public void Initialize()
        {
            int connectionLayerCount = layerModel.Length - 1;
            weights = new Matrix<T>[connectionLayerCount];
            biases = new Matrix<T>[connectionLayerCount];
            unitS = new Matrix<T>[layerModel.Length];
            unitV = new Matrix<T>[layerModel.Length];
            unitD = new Matrix<T>[layerModel.Length];

            for (int i = 0; i < connectionLayerCount; i++)
            {
                weights[i] = new Matrix<T>(layerModel[i], layerModel[i + 1]);
                biases[i] = new Matrix<T>(1, layerModel[i + 1]);
                weights[i].Map(mapMin, mapMax);
                biases[i].Map(mapMin, mapMax);
                Console.WriteLine("\nLayer {0}-{1} weights", i, i + 1);
                Matrix<T>.EnumerateMatrix(weights[i].GetMatrix());
                Console.WriteLine("\nLayer {0} biases", i + 1);
                Matrix<T>.EnumerateMatrix(biases[i].GetMatrix());
            }
            Console.WriteLine();
            for (int i = 0; i < layerModel.Length; i++)
            {
                unitS[i] = new Matrix<T>(1, layerModel[i]);
                unitV[i] = new Matrix<T>(1, layerModel[i]);
                unitD[i] = new Matrix<T>(1, layerModel[i]);
                if (i == 0)
                {
                    Console.WriteLine("InputLayer {0} count = {1}", i, layerModel[i]);
                }
                else if (i == layerModel.Length - 1)
                {
                    Console.WriteLine("OutputLayer {0} count = {1}", i, layerModel[i]);
                }
                else
                {
                    Console.WriteLine("HiddenLayer {0} count = {1}", i, layerModel[i]);
                }
            }
        }

        public void Train(Matrix<T> inputData, Matrix<T> desiredOutputData)
        {
            Console.WriteLine("\nFeeding Forward...");
            for (int i = 0; i < layerModel.Length; i++)
            {
                if (i == 0)//Input Layer
                {
                    unitV[i] = inputData;
                    Console.WriteLine("\nInput");
                    Matrix<T>.EnumerateMatrix(unitV[i].GetMatrix());
                }
                else
                {
                    unitS[i] = (unitV[i - 1] * weights[i - 1]) + biases[i - 1];
                    unitV[i] = unitS[i].DeepCopy();
                    unitV[i].ApplyFunction(ActivationFunction);
                }
            }
            Console.WriteLine("Feed Forward Output");
            Matrix<T>.EnumerateMatrix(unitV[unitV.Length - 1].GetMatrix());
            Matrix<T> errorTable = unitV[unitV.Length - 1];
            errorTable = (errorTable - desiredOutputData);
            errorTable.ApplyFunction((T x) => x * (dynamic)x);
            Console.WriteLine("Error Found");
            Matrix<T>.EnumerateMatrix(errorTable.GetMatrix());

            for (int i = layerModel.Length - 1; i >= 0; i--)
            {
                if (i == layerModel.Length - 1)//Output Layer
                {
                    //since i indicates last index of each array,
                    Matrix<T> errorDiff = unitV[i].DeepCopy();
                    errorDiff = (dynamic)2 * (errorDiff - desiredOutputData);//d error / d output f(z)
                    Matrix<T> actFDiff = unitS[i].DeepCopy();
                    actFDiff.ApplyFunction(ActivationFunctionPrime);//d output f(z) / d output z
                    T[,] ed = errorDiff.GetMatrix();
                    T[,] fd = actFDiff.GetMatrix();
                    T[,] outD = new T[ed.GetLength(0), ed.GetLength(1)];
                    for (int j = 0; j < ed.GetLength(0); j++)
                    {
                        for (int k = 0; k < ed.GetLength(1); k++)
                        {
                            outD[j, k] = (dynamic)ed[j, k] * fd[j, k];
                        }
                    }
                    unitD[i] = new Matrix<T>(outD);
                }
                else
                {
                    /*
                    unitD[i] = unitD[i + 1] * weights[i];//This will work only if each layer has same amount of unit
                    Matrix<T> actFDiff = unitS[i];
                    actFDiff.ApplyFunction(ActivationFunctionPrime);
                    unitD[i] = unitD[i] ^ actFDiff;
                    */
                    T[,] foreDelta = unitD[i + 1].GetMatrix();
                    T[,] tempWeight = weights[i].GetMatrix();
                    T[,] tempDelta = new T[tempWeight.GetLength(0), 1];//---------!!!---------assuring input of only one data

                    for (int j = 0; j < tempDelta.GetLength(0); j++)
                    {
                        for (int k = 0; k < layerModel[i + 1]; k++)
                        {
                            tempDelta[j, 0] = (dynamic)tempWeight[j, k] * foreDelta[0, k];//---------!!!---------assuring input of only one data
                        }
                    }

                    unitD[i] = new Matrix<T>(tempDelta);
                    unitD[i].InverseByDiagonalLine();
                    Matrix<T> actFDiff = unitS[i].DeepCopy();
                    actFDiff.ApplyFunction(ActivationFunctionPrime);
                    unitD[i] = unitD[i] ^ actFDiff;
                }
            }

            /*for (int i = 0; i < unitD.Length; i++)
            {
                Console.WriteLine("\nLayer {0} delta", i);
                Matrix<T>.EnumerateMatrix(unitD[i].GetMatrix());
            }*/

            Console.WriteLine("Backpropagating...");
            for (int i = layerModel.Length - 1; i > 0; i--)
            {
                T[,] tempWeights = weights[i - 1].GetMatrix();
                T[,] tempUnitV = unitV[i - 1].GetMatrix();
                T[,] tempDelta = unitD[i].GetMatrix();
                for (int j = 0; j < tempWeights.GetLength(0); j++)
                {
                    for (int k = 0; k < tempWeights.GetLength(1); k++)
                    {
                        tempWeights[j, k] = tempWeights[j, k] - (dynamic)learningRate * tempDelta[0, k] * tempUnitV[0, j];//---------!!!---------assuring input of only one data
                    }
                }
                weights[i - 1] = new Matrix<T>(tempWeights);

                biases[i - 1] = biases[i - 1] - (learningRate * unitD[i]);
            }
            Console.WriteLine("Back Prop Done.");
        }

        public void Train_Silent(Matrix<T> inputData, Matrix<T> desiredOutputData)
        {
            for (int i = 0; i < layerModel.Length; i++)
            {
                if (i == 0)//Input Layer
                {
                    unitV[i] = inputData;
                }
                else
                {
                    unitS[i] = (unitV[i - 1] * weights[i - 1]) + biases[i - 1];
                    unitV[i] = unitS[i].DeepCopy();
                    unitV[i].ApplyFunction(ActivationFunction);
                }
            }
            Matrix<T> errorTable = unitV[unitV.Length - 1];
            errorTable = (errorTable - desiredOutputData);
            errorTable.ApplyFunction((T x) => x * (dynamic)x);

            for (int i = layerModel.Length - 1; i >= 0; i--)
            {
                if (i == layerModel.Length - 1)//Output Layer
                {
                    //since i indicates last index of each array,
                    Matrix<T> errorDiff = unitV[i].DeepCopy();
                    errorDiff = (dynamic)2 * (errorDiff - desiredOutputData);//d error / d output f(z)
                    Matrix<T> actFDiff = unitS[i].DeepCopy();
                    actFDiff.ApplyFunction(ActivationFunctionPrime);//d output f(z) / d output z
                    T[,] ed = errorDiff.GetMatrix();
                    T[,] fd = actFDiff.GetMatrix();
                    T[,] outD = new T[ed.GetLength(0), ed.GetLength(1)];
                    for (int j = 0; j < ed.GetLength(0); j++)
                    {
                        for (int k = 0; k < ed.GetLength(1); k++)
                        {
                            outD[j, k] = (dynamic)ed[j, k] * fd[j, k];
                        }
                    }
                    unitD[i] = new Matrix<T>(outD);
                }
                else
                {
                    /*
                    unitD[i] = unitD[i + 1] * weights[i];//This will work only if each layer has same amount of unit
                    Matrix<T> actFDiff = unitS[i];
                    actFDiff.ApplyFunction(ActivationFunctionPrime);
                    unitD[i] = unitD[i] ^ actFDiff;
                    */
                    T[,] foreDelta = unitD[i + 1].GetMatrix();
                    T[,] tempWeight = weights[i].GetMatrix();
                    T[,] tempDelta = new T[tempWeight.GetLength(0), 1];//---------!!!---------assuring input of only one data

                    for (int j = 0; j < tempDelta.GetLength(0); j++)
                    {
                        for (int k = 0; k < layerModel[i + 1]; k++)
                        {
                            tempDelta[j, 0] = (dynamic)tempWeight[j, k] * foreDelta[0, k];//---------!!!---------assuring input of only one data
                        }
                    }

                    unitD[i] = new Matrix<T>(tempDelta);
                    unitD[i].InverseByDiagonalLine();
                    Matrix<T> actFDiff = unitS[i].DeepCopy();
                    actFDiff.ApplyFunction(ActivationFunctionPrime);
                    unitD[i] = unitD[i] ^ actFDiff;
                }
            }

            /*for (int i = 0; i < unitD.Length; i++)
            {
                Console.WriteLine("\nLayer {0} delta", i);
                Matrix<T>.EnumerateMatrix(unitD[i].GetMatrix());
            }*/

            for (int i = layerModel.Length - 1; i > 0; i--)
            {
                T[,] tempWeights = weights[i - 1].GetMatrix();
                T[,] tempUnitV = unitV[i - 1].GetMatrix();
                T[,] tempDelta = unitD[i].GetMatrix();
                for (int j = 0; j < tempWeights.GetLength(0); j++)
                {
                    for (int k = 0; k < tempWeights.GetLength(1); k++)
                    {
                        tempWeights[j, k] = tempWeights[j, k] - (dynamic)learningRate * tempDelta[0, k] * tempUnitV[0, j];//---------!!!---------assuring input of only one data
                    }
                }
                weights[i - 1] = new Matrix<T>(tempWeights);

                biases[i - 1] = biases[i - 1] - (learningRate * unitD[i]);
            }
        }

        public void Predict(Matrix<T> inputData)
        {
            Console.WriteLine("\nFeeding Forward...");
            for (int i = 0; i < layerModel.Length; i++)
            {
                if (i == 0)//Input Layer
                {
                    unitV[i] = inputData;
                    Console.WriteLine("\nInput");
                    Matrix<T>.EnumerateMatrix(unitV[i].GetMatrix());
                }
                else
                {
                    unitS[i] = (unitV[i - 1] * weights[i - 1]) + biases[i - 1];
                    unitV[i] = unitS[i].DeepCopy();
                    unitV[i].ApplyFunction(ActivationFunction);
                }
            }
            Console.WriteLine("Feed Forward Output");
            Matrix<T>.EnumerateMatrix(unitV[unitV.Length - 1].GetMatrix());
        }

        public void Debug()
        {
            Console.WriteLine("--------------------<Neural Network Debug Report>--------------------");
            Console.WriteLine("\n1.Pre-described info");
            Console.WriteLine("Mapping Range = {0} ~ {1}", mapMin, mapMax);
            Console.WriteLine("Learning Rate = {0}", learningRate);

            Console.WriteLine("\n2.Pre-designed info");
            Console.WriteLine("LayerCount : {0}", layerModel.Length);
            for (int i = 0; i < layerModel.Length; i++)
            {
                Console.WriteLine("Layer {0} unit count : {1}", i, layerModel[i]);
            }
            for (int i = 0; i < layerModel.Length - 1; i++)
            {
                Console.WriteLine("\nConnectionLayer {0} : L{0}-L{1}", i, i + 1);
                Console.WriteLine("\nWeight");
                Matrix<T>.EnumerateMatrix(weights[i].GetMatrix());
                Console.WriteLine("\nBias");
                Matrix<T>.EnumerateMatrix(biases[i].GetMatrix());
            }

            Console.WriteLine("\n3. Latest train info");
            for (int i = 0; i < layerModel.Length; i++)
            {
                Console.WriteLine("\nLayer {0} train result", i);
                Console.WriteLine("\nunit Sum");
                Matrix<T>.EnumerateMatrix(unitS[i].GetMatrix());
                Console.WriteLine("\nunit Value=func(sum)");
                Matrix<T>.EnumerateMatrix(unitV[i].GetMatrix());
                Console.WriteLine("\nunit Delta");
                Matrix<T>.EnumerateMatrix(unitD[i].GetMatrix());
            }
            Console.WriteLine("--------------------<Neural Network Debug Report>--------------------");
        }

        public void Log()
        {

        }

        public void SaveModelData()
        {
            object[] data = new object[9];
            data[0] = layerModel;
            data[1] = weights;
            data[2] = biases;
            data[3] = unitS;
            data[4] = unitV;
            data[5] = unitD;
            data[6] = mapMax;
            data[7] = mapMin;
            data[8] = learningRate;
            using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
            {
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                bf.Serialize(ms, data);
                System.IO.File.WriteAllBytes(path, ms.ToArray());
            }
            Console.WriteLine("Model data saved.");
        }

        public void LoadModelData()
        {
            if (System.IO.File.Exists(path) == true)
            {
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                {
                    System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    byte[] sData = System.IO.File.ReadAllBytes(path);
                    ms.Write(sData, 0, sData.Length);
                    ms.Seek(0, System.IO.SeekOrigin.Begin);
                    object[] data = (object[])bf.Deserialize(ms);
                    layerModel = (int[])data[0];
                    weights = (Matrix<T>[])data[1];
                    biases = (Matrix<T>[])data[2];
                    unitS = (Matrix<T>[])data[3];
                    unitV = (Matrix<T>[])data[4];
                    unitD = (Matrix<T>[])data[5];
                    mapMax = (T)data[6];
                    mapMin = (T)data[7];
                    learningRate = (T)data[8];
                }
                Console.WriteLine("Model data loaded.");
            }
            else
            {
                Console.WriteLine("Model data not found at {0}", path);
            }
        }

        private T FindError(T x, T y)
        {
            return (x - (dynamic)y) * (x - (dynamic)y);
        }

        private T ErrorFindPrime(T x, T y)
        {
            return 2 * (x - (dynamic)y);
        }

        private T ActivationFunction(T x)
        {
            return Sigmoid(x);
        }

        private T ActivationFunctionPrime(T x)
        {
            return SigmoidPrime(x);
        }

        private T Sigmoid(T x)
        {
            return 1 / (1 + Math.Pow(Math.E, -(dynamic)x));
        }

        private T SigmoidPrime(T x)
        {
            return Sigmoid(x) * (1 - (dynamic)Sigmoid(x));
        }

        private T Tanh(T x)
        {
            return 2 * Sigmoid(2 * (dynamic)x) - 1;
        }

        private T TanhPrime(T x)
        {
            return 1 - Tanh(x) * (dynamic)Tanh(x);
        }
    }
}