﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LearningModel;
using Matrices;

namespace MachineLearning
{
    class Program
    {
        static void Main(string[] args)
        {
            /*LearningModel<double> a = new LearningModel<double>(new int[] { 2, 2, 1 });
            a.Initialize();
            a.weights[0] = new Matrix<double>(new double[,] {{ 0.1, 0.2 },{ 0.3, 0.4 }});
            a.weights[1] = new Matrix<double>(new double[,] { { 0.5 }, { 0.6 } });
            a.biases[0] = new Matrix<double>(new double[,] { { 0.3, 0.4 } });
            a.biases[1] = new Matrix<double>(new double[,] { { 0.5 } });
            Matrix<double> i1 = new Matrix<double>(new double[,] { { 0.5, 1 } });
            Matrix<double> o1 = new Matrix<double>(new double[,] { { 1 } });
            a.Train(i1, o1);
            a.Debug();
            Console.WriteLine(a.weights[1].GetMatrix()[0, 0]);
            Console.ReadKey();*/

            LearningModel<double> a = new LearningModel<double>(new int[] { 2, 2, 2, 1 });

            Matrix<double> i1 = new Matrix<double>(new double[,] { { 5, 5 } });
            Matrix<double> o1 = new Matrix<double>(new double[,] { { 0 } });

            Matrix<double> i2 = new Matrix<double>(new double[,] { { 1, 1 } });
            Matrix<double> o2 = new Matrix<double>(new double[,] { { 1 } });

            Matrix<double> i3 = new Matrix<double>(new double[,] { { 1, 0 } });
            Matrix<double> o3 = new Matrix<double>(new double[,] { { 0 } });

            Matrix<double> i4 = new Matrix<double>(new double[,] { { 0, 1 } });
            Matrix<double> o4 = new Matrix<double>(new double[,] { { 0 } });

            do
            {
                switch (Console.ReadKey().Key)
                {
                    case ConsoleKey.X:
                        Console.WriteLine("Program ended, Press any key to exit...");
                        Console.ReadKey();
                        return;
                    case ConsoleKey.D:
                        a.Debug();
                        break;
                    case ConsoleKey.I:
                        a.Initialize();
                        break;
                    case ConsoleKey.S:
                        a.SaveModelData();
                        break;
                    case ConsoleKey.L:
                        a.LoadModelData();
                        break;
                    case ConsoleKey.P:
                        Console.Write("Predict Mode : ");
                        string[] data = Console.ReadLine().Replace(" ", "").Split(',');
                        double[,] test = new double[1, data.Length];
                        for (int i = 0; i < data.Length; i++)
                        {
                            test[0, i] = double.Parse(data[i]);
                        }
                        a.Predict(new Matrix<double>(test));
                        break;
                    case ConsoleKey.V:
                        Console.WriteLine("Learning rate change:");
                        a.learningRate = double.Parse(Console.ReadLine());
                        break;
                    case ConsoleKey.T:
                        Console.Write("How many steps? : ");
                        int count = int.Parse(Console.ReadLine());
                        Console.WriteLine("This would take about {0} seconds", count * 7);
                        Console.WriteLine("This would take about {0} minutes", count * 7 / 60f);
                        for (int i = 0; i < 100000 * count; i++)
                        {
                            /*if (Console.Title.Contains(';'))
                            {
                                Console.Title = Console.Title.Split(';')[0] + string.Format(";{0}%", (float)i / 1000);
                            }
                            else
                            {
                                Console.Title += ';';
                            }*/
                            a.Train_Silent(i1, o1);
                            a.Train_Silent(i2, o2);
                            a.Train_Silent(i3, o3);
                            a.Train_Silent(i4, o4);
                        }
                        Console.WriteLine("Done");
                        break;
                    default:
                        a.Train(i1, o1);
                        a.Train(i2, o2);
                        a.Train(i3, o3);
                        a.Train(i4, o4);
                        break;
                }
            } while (true);
        }
    }
}