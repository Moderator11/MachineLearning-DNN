﻿using System;
using Matrices;

namespace LearningModel//Written by Soomin Park, In ‎2022‎-07‎-09 saturday, 8:26:50 pm.
{
    class LearningModel<T> : Base.LearningModelBase<T>
    {
        string path = Environment.CurrentDirectory + @"\Model-Data.mldat";

        int[] layerModel;

        public Matrix<T>[] weights;
        public Matrix<T>[] biases;
        Matrix<T>[] unitSum;
        Matrix<T>[] unitOut;
        Matrix<T>[] unitDelta;

        public T mapMax = (T)Convert.ChangeType(1, typeof(T));
        public T mapMin = (T)Convert.ChangeType(-1, typeof(T));
        public T learningRate = (T)Convert.ChangeType(0.01, typeof(T));

        public LearningModel(int[] _layerModel)
        {
            layerModel = _layerModel;
        }

        public void Initialize()
        {
            int connectionLayerCount = layerModel.Length - 1;

            RunInitialize();

            void RunInitialize()
            {
                Init_MatrixVariables();
                Init_BiasnWeights();
                Init_StateVectors();
            }

            void Init_MatrixVariables()
            {
                weights = new Matrix<T>[connectionLayerCount];
                biases = new Matrix<T>[connectionLayerCount];
                unitSum = new Matrix<T>[layerModel.Length];
                unitOut = new Matrix<T>[layerModel.Length];
                unitDelta = new Matrix<T>[layerModel.Length];
            }

            void Init_BiasnWeights()
            {
                for (int i = 0; i < connectionLayerCount; i++)
                {
                    weights[i] = new Matrix<T>(layerModel[i], layerModel[i + 1]);
                    biases[i] = new Matrix<T>(1, layerModel[i + 1]);
                    weights[i].Map(mapMin, mapMax);
                    biases[i].Map(mapMin, mapMax);
                    Console.WriteLine("\nLayer {0}-{1} weights", i, i + 1);
                    Matrix<T>.EnumerateMatrix(weights[i].GetMatrix());
                    Console.WriteLine("\nLayer {0} biases", i + 1);
                    Matrix<T>.EnumerateMatrix(biases[i].GetMatrix());
                }
                Console.WriteLine();
            }

            void Init_StateVectors()
            {
                for (int i = 0; i < layerModel.Length; i++)
                {
                    unitSum[i] = new Matrix<T>(1, layerModel[i]);
                    unitOut[i] = new Matrix<T>(1, layerModel[i]);
                    unitDelta[i] = new Matrix<T>(1, layerModel[i]);
                    if (i == 0)
                    {
                        Console.WriteLine("InputLayer {0} count = {1}", i, layerModel[i]);
                    }
                    else if (i == layerModel.Length - 1)
                    {
                        Console.WriteLine("OutputLayer {0} count = {1}", i, layerModel[i]);
                    }
                    else
                    {
                        Console.WriteLine("HiddenLayer {0} count = {1}", i, layerModel[i]);
                    }
                }
            }
        }

        public void Initialize_Silent()
        {
            int connectionLayerCount = layerModel.Length - 1;

            RunInitialize();

            void RunInitialize()
            {
                Init_MatrixVariables();
                Init_BiasnWeights();
                Init_StateVectors();
            }

            void Init_MatrixVariables()
            {
                weights = new Matrix<T>[connectionLayerCount];
                biases = new Matrix<T>[connectionLayerCount];
                unitSum = new Matrix<T>[layerModel.Length];
                unitOut = new Matrix<T>[layerModel.Length];
                unitDelta = new Matrix<T>[layerModel.Length];
            }

            void Init_BiasnWeights()
            {
                for (int i = 0; i < connectionLayerCount; i++)
                {
                    weights[i] = new Matrix<T>(layerModel[i], layerModel[i + 1]);
                    biases[i] = new Matrix<T>(1, layerModel[i + 1]);
                    weights[i].Map(mapMin, mapMax);
                    biases[i].Map(mapMin, mapMax);
                }
            }

            void Init_StateVectors()
            {
                for (int i = 0; i < layerModel.Length; i++)
                {
                    unitSum[i] = new Matrix<T>(1, layerModel[i]);
                    unitOut[i] = new Matrix<T>(1, layerModel[i]);
                    unitDelta[i] = new Matrix<T>(1, layerModel[i]);
                }
            }
        }

        public void Train(Matrix<T> inputData, Matrix<T> desiredOutputData)
        {
            RunCycle();

            void RunCycle()
            {
                FeedForward();
                FindError();
                CalculateDelta();
                BackPropagate();
            }

            void FeedForward()
            {
                Console.WriteLine("\nFeeding Forward...");
                for (int i = 0; i < layerModel.Length; i++)
                {
                    if (i == 0)//Input Layer
                    {
                        unitOut[i] = inputData;
                        Console.WriteLine("\nInput");
                        Matrix<T>.EnumerateMatrix(unitOut[i].GetMatrix());
                    }
                    else
                    {
                        unitSum[i] = (unitOut[i - 1] * weights[i - 1]) + biases[i - 1];
                        unitOut[i] = unitSum[i].DeepCopy();
                        unitOut[i].ApplyFunction(ActivationFunction);
                    }
                }
                Console.WriteLine("Feed Forward Output");
                Matrix<T>.EnumerateMatrix(unitOut[unitOut.Length - 1].GetMatrix());
            }

            void FindError()
            {
                Matrix<T> errorTable = unitOut[unitOut.Length - 1];
                errorTable = (errorTable - desiredOutputData);
                errorTable.ApplyFunction((T x) => x * (dynamic)x);
                Console.WriteLine("Error Found");
                Matrix<T>.EnumerateMatrix(errorTable.GetMatrix());
            }//FindError does not need neccesarily since CalculateDelta does have independent error calculation and FindError is just for visualization

            void CalculateDelta()
            {
                for (int i = layerModel.Length - 1; i >= 0; i--)
                {
                    if (i == layerModel.Length - 1)//Output Layer
                    {
                        //since i indicates last index of each array,
                        Matrix<T> errorDiff = unitOut[i].DeepCopy();
                        errorDiff = (dynamic)2 * (errorDiff - desiredOutputData);//d error / d output f(z)
                        Matrix<T> actFDiff = unitSum[i].DeepCopy();
                        actFDiff.ApplyFunction(ActivationFunctionPrime);//d output f(z) / d output z
                        T[,] ed = errorDiff.GetMatrix();
                        T[,] fd = actFDiff.GetMatrix();
                        T[,] outD = new T[ed.GetLength(0), ed.GetLength(1)];
                        for (int j = 0; j < ed.GetLength(0); j++)
                        {
                            for (int k = 0; k < ed.GetLength(1); k++)
                            {
                                outD[j, k] = (dynamic)ed[j, k] * fd[j, k];
                            }
                        }
                        unitDelta[i] = new Matrix<T>(outD);
                    }
                    else
                    {
                        Newest_FIndDelta();

                        void Fail0()
                        {
                            unitDelta[i] = unitDelta[i + 1] * weights[i];
                            Matrix<T> actFDiff = unitSum[i];
                            actFDiff.ApplyFunction(ActivationFunctionPrime);
                            unitDelta[i] = unitDelta[i] ^ actFDiff;
                        }//This will works only if each layer has same amount of unit

                        void Fail1()
                        {
                            T[,] foreDelta = unitDelta[i + 1].GetMatrix();
                            T[,] tempWeight = weights[i].GetMatrix();
                            T[,] tempDelta = new T[tempWeight.GetLength(0), 1];//---------!!!---------assuring input of only one data

                            for (int j = 0; j < tempDelta.GetLength(0); j++)
                            {
                                for (int k = 0; k < layerModel[i + 1]; k++)
                                {
                                    tempDelta[j, 0] = (dynamic)tempWeight[j, k] * foreDelta[0, k];//---------!!!---------assuring input of only one data
                                }
                            }

                            unitDelta[i] = new Matrix<T>(tempDelta);
                            unitDelta[i].InverseByDiagonalLine();
                            Matrix<T> actFDiff = unitSum[i].DeepCopy();
                            actFDiff.ApplyFunction(ActivationFunctionPrime);
                            unitDelta[i] = unitDelta[i] ^ actFDiff;
                        }//This wil works only when layer has (n to 1) connection

                        void Newest_FIndDelta()
                        {
                            Matrix<T> foreDelta = unitDelta[i + 1].DeepCopy();
                            Matrix<T> tempWeight = weights[i].DeepCopy();
                            int currentUnitCount = tempWeight.GetMatrix().GetLength(0);
                            Matrix<T> tempDelta = new Matrix<T>(1, currentUnitCount);
                            foreDelta.InverseByDiagonalLine();
                            tempDelta = tempWeight * foreDelta;

                            tempDelta.InverseByDiagonalLine();
                            Matrix<T> actFDiff = unitSum[i].DeepCopy();
                            actFDiff.ApplyFunction(ActivationFunctionPrime);
                            unitDelta[i] = tempDelta ^ actFDiff;
                        }
                    }
                }
                /*for (int i = 0; i < unitD.Length; i++)
                {
                    Console.WriteLine("\nLayer {0} delta", i);
                    Matrix<T>.EnumerateMatrix(unitD[i].GetMatrix());
                }*/
            }

            void BackPropagate()
            {
                Console.WriteLine("Backpropagating...");
                for (int i = layerModel.Length - 1; i > 0; i--)
                {
                    T[,] tempWeights = weights[i - 1].GetMatrix();
                    T[,] tempUnitV = unitOut[i - 1].GetMatrix();
                    T[,] tempDelta = unitDelta[i].GetMatrix();
                    for (int j = 0; j < tempWeights.GetLength(0); j++)
                    {
                        for (int k = 0; k < tempWeights.GetLength(1); k++)
                        {
                            tempWeights[j, k] = tempWeights[j, k] - (dynamic)learningRate * tempDelta[0, k] * tempUnitV[0, j];//---------!!!---------assuring input of only one data
                        }
                    }
                    weights[i - 1] = new Matrix<T>(tempWeights);

                    biases[i - 1] = biases[i - 1] - (learningRate * unitDelta[i]);
                }
                Console.WriteLine("Back Prop Done.");
            }
        }

        public void Train_Silent(Matrix<T> inputData, Matrix<T> desiredOutputData)
        {
            RunCycle_Silent();

            void RunCycle_Silent()
            {
                FeedForward();
                CalculateDelta();
                BackPropagate();
            }

            void FeedForward()
            {
                for (int i = 0; i < layerModel.Length; i++)
                {
                    if (i == 0)
                    {
                        unitOut[i] = inputData;
                    }
                    else
                    {
                        unitSum[i] = (unitOut[i - 1] * weights[i - 1]) + biases[i - 1];
                        unitOut[i] = unitSum[i].DeepCopy();
                        unitOut[i].ApplyFunction(ActivationFunction);
                    }
                }
            }

            void CalculateDelta()
            {
                for (int i = layerModel.Length - 1; i >= 0; i--)
                {
                    if (i == layerModel.Length - 1)//Output Layer
                    {
                        //since i indicates last index of each array,
                        Matrix<T> errorDiff = unitOut[i].DeepCopy();
                        errorDiff = (dynamic)2 * (errorDiff - desiredOutputData);//d error / d output f(z)
                        Matrix<T> actFDiff = unitSum[i].DeepCopy();
                        actFDiff.ApplyFunction(ActivationFunctionPrime);//d output f(z) / d output z
                        T[,] ed = errorDiff.GetMatrix();
                        T[,] fd = actFDiff.GetMatrix();
                        T[,] outD = new T[ed.GetLength(0), ed.GetLength(1)];
                        for (int j = 0; j < ed.GetLength(0); j++)
                        {
                            for (int k = 0; k < ed.GetLength(1); k++)
                            {
                                outD[j, k] = (dynamic)ed[j, k] * fd[j, k];
                            }
                        }
                        unitDelta[i] = new Matrix<T>(outD);
                    }
                    else
                    {
                        Matrix<T> foreDelta = unitDelta[i + 1].DeepCopy();
                        Matrix<T> tempWeight = weights[i].DeepCopy();
                        int currentUnitCount = tempWeight.GetMatrix().GetLength(0);
                        Matrix<T> tempDelta = new Matrix<T>(1, currentUnitCount);
                        foreDelta.InverseByDiagonalLine();
                        tempDelta = tempWeight * foreDelta;

                        tempDelta.InverseByDiagonalLine();
                        Matrix<T> actFDiff = unitSum[i].DeepCopy();
                        actFDiff.ApplyFunction(ActivationFunctionPrime);
                        unitDelta[i] = tempDelta ^ actFDiff;
                    }
                }
                /*for (int i = 0; i < unitD.Length; i++)
                {
                    Console.WriteLine("\nLayer {0} delta", i);
                    Matrix<T>.EnumerateMatrix(unitD[i].GetMatrix());
                }*/
            }

            void BackPropagate()
            {
                for (int i = layerModel.Length - 1; i > 0; i--)
                {
                    T[,] tempWeights = weights[i - 1].GetMatrix();
                    T[,] tempUnitV = unitOut[i - 1].GetMatrix();
                    T[,] tempDelta = unitDelta[i].GetMatrix();
                    for (int j = 0; j < tempWeights.GetLength(0); j++)
                    {
                        for (int k = 0; k < tempWeights.GetLength(1); k++)
                        {
                            tempWeights[j, k] = tempWeights[j, k] - (dynamic)learningRate * tempDelta[0, k] * tempUnitV[0, j];
                        }
                    }
                    weights[i - 1] = new Matrix<T>(tempWeights);

                    biases[i - 1] = biases[i - 1] - (learningRate * unitDelta[i]);
                }
            }
        }

        public void Predict(Matrix<T> inputData)
        {
            Console.WriteLine("\nFeeding Forward...");
            for (int i = 0; i < layerModel.Length; i++)
            {
                if (i == 0)//Input Layer
                {
                    unitOut[i] = inputData;
                    Console.WriteLine("\nInput");
                    Matrix<T>.EnumerateMatrix(unitOut[i].GetMatrix());
                }
                else
                {
                    unitSum[i] = (unitOut[i - 1] * weights[i - 1]) + biases[i - 1];
                    unitOut[i] = unitSum[i].DeepCopy();
                    unitOut[i].ApplyFunction(ActivationFunction);
                }
            }
            Console.WriteLine("Feed Forward Output");
            Matrix<T>.EnumerateMatrix(unitOut[unitOut.Length - 1].GetMatrix());
        }

        public void Debug()
        {
            Console.WriteLine("--------------------<Neural Network Debug Report>--------------------");
            Console.WriteLine("\n1.Pre-described info");
            Console.WriteLine("Mapping Range = {0} ~ {1}", mapMin, mapMax);
            Console.WriteLine("Learning Rate = {0}", learningRate);

            Console.WriteLine("\n2.Pre-designed info");
            Console.WriteLine("LayerCount : {0}", layerModel.Length);
            for (int i = 0; i < layerModel.Length; i++)
            {
                Console.WriteLine("Layer {0} unit count : {1}", i, layerModel[i]);
            }
            for (int i = 0; i < layerModel.Length - 1; i++)
            {
                Console.WriteLine("\nConnectionLayer {0} : L{0}-L{1}", i, i + 1);
                Console.WriteLine("\nWeight");
                Matrix<T>.EnumerateMatrix(weights[i].GetMatrix());
                Console.WriteLine("\nBias");
                Matrix<T>.EnumerateMatrix(biases[i].GetMatrix());
            }

            Console.WriteLine("\n3. Latest train info");
            for (int i = 0; i < layerModel.Length; i++)
            {
                Console.WriteLine("\nLayer {0} train result", i);
                Console.WriteLine("\nunit Sum");
                Matrix<T>.EnumerateMatrix(unitSum[i].GetMatrix());
                Console.WriteLine("\nunit Value=func(sum)");
                Matrix<T>.EnumerateMatrix(unitOut[i].GetMatrix());
                Console.WriteLine("\nunit Delta");
                Matrix<T>.EnumerateMatrix(unitDelta[i].GetMatrix());
            }
            Console.WriteLine("--------------------<Neural Network Debug Report>--------------------");
        }

        public void Log(Matrix<T> inputData, Matrix<T> desiredOutputData)
        {
            //Train
            //Log
            //Train
            //Log
        }

        public void SaveModelData()
        {
            object[] data = new object[9];
            data[0] = layerModel;
            data[1] = weights;
            data[2] = biases;
            data[3] = unitSum;
            data[4] = unitOut;
            data[5] = unitDelta;
            data[6] = mapMax;
            data[7] = mapMin;
            data[8] = learningRate;
            using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
            {
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                bf.Serialize(ms, data);
                System.IO.File.WriteAllBytes(path, ms.ToArray());
            }
            Console.WriteLine("Model data saved.");
        }

        public void LoadModelData()
        {
            if (System.IO.File.Exists(path) == true)
            {
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                {
                    System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    byte[] sData = System.IO.File.ReadAllBytes(path);
                    ms.Write(sData, 0, sData.Length);
                    ms.Seek(0, System.IO.SeekOrigin.Begin);
                    object[] data = (object[])bf.Deserialize(ms);
                    layerModel = (int[])data[0];
                    weights = (Matrix<T>[])data[1];
                    biases = (Matrix<T>[])data[2];
                    unitSum = (Matrix<T>[])data[3];
                    unitOut = (Matrix<T>[])data[4];
                    unitDelta = (Matrix<T>[])data[5];
                    mapMax = (T)data[6];
                    mapMin = (T)data[7];
                    learningRate = (T)data[8];
                }
                Console.WriteLine("Model data loaded.");
            }
            else
            {
                Console.WriteLine("Model data not found at {0}", path);
            }
        }

        private T FindError(T x, T y)
        {
            return MeanSquareError(x, y);
        }

        private T ErrorFindPrime(T x, T y)
        {
            return MeanSquareErrorPrime(x, y);
        }

        private T ActivationFunction(T x)
        {
            return Sigmoid(x);
        }

        private T ActivationFunctionPrime(T x)
        {
            return SigmoidPrime(x);
        }
    }
}