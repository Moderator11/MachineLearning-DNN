﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LearningModel;
using Matrices;

namespace MachineLearning
{
    class Program
    {
        static void Main(string[] args)
        {
            Test();
        }

        static void Test()
        {
            LearningModelTester tester = new LearningModelTester();
            tester.Tester_1();
        }

        static void BatchDevelopment()
        {
            LearningModel.Test.LearningModel<double> a = new LearningModel.Test.LearningModel<double>(new int[] { 2, 2, 2, 1 });

            Matrix<double> i1 = new Matrix<double>(new double[,] { { 0, 0 } });
            Matrix<double> o1 = new Matrix<double>(new double[,] { { 0 } });

            Matrix<double> i2 = new Matrix<double>(new double[,] { { 1, 1 } });
            Matrix<double> o2 = new Matrix<double>(new double[,] { { 1 } });

            Matrix<double> i3 = new Matrix<double>(new double[,] { { 1, 0 } });
            Matrix<double> o3 = new Matrix<double>(new double[,] { { 0 } });

            Matrix<double> i4 = new Matrix<double>(new double[,] { { 0, 1 } });
            Matrix<double> o4 = new Matrix<double>(new double[,] { { 0 } });

            /*Matrix<double> batchIn = new Matrix<double>(new double[,] { { 0, 0 }, { 1, 1 }, { 1, 0 }, { 0, 1 } });
            Matrix<double> batchOut = new Matrix<double>(new double[,] { { 0 }, { 1 }, { 0 }, { 0 } });

            a.Initialize();
            //a.Train_Batch(batchIn, batchOut);
            a.Train_Batch(i1, o1);
            Console.ReadKey();*/

            a.Initialize();
            a.Train_Batch(i1, o1);
            /*for (int i = 0; i < 100; i++)
            {
                a.Train_Batch(i1, o1);
                a.Train_Batch(i2, o2);
                a.Train_Batch(i3, o3);
                a.Train_Batch(i4, o4);
            }
            a.Predict(new Matrix<double>(new double[,] { { 0, 0 } }));
            a.Predict(new Matrix<double>(new double[,] { { 1, 1 } }));
            a.Predict(new Matrix<double>(new double[,] { { 1, 0 } }));
            a.Predict(new Matrix<double>(new double[,] { { 0, 1 } }));*/
            Console.ReadKey();
        }
    }
}