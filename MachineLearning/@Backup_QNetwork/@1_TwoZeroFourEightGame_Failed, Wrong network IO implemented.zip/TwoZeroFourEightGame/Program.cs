﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Matrices;

namespace TwoZeroFourEightGame
{
    class Program
    {
        static void Main(string[] args)
        {
            //TwoZeroFourEight game = new TwoZeroFourEight();
            //game.StartConsoleInterfacedGame();

            //FindTheTreasure.FindTheTreasure game = new FindTheTreasure.FindTheTreasure();
            //game.StartConsoleInterfacedGame();

            LearningModel.LearningModel_QLearning dqn = new LearningModel.LearningModel_QLearning(new int[] { 2, 20, 20, 4 }, new string[] { "relu", "leakyrelu", "leakyrelu", "leakyrelu" }, "MSE");

            FindTheTreasure.FindTheTreasure game = new FindTheTreasure.FindTheTreasure();

            //TestGame(dqn, game);

            int episods = 50;
            for (int i = 0; i < episods; i++)
            {
                Console.WriteLine("Episode {0}", i);
                do {
                    RunGame(dqn, game);
                } while (game.CheckGameValid() == true);
            }

            TestGame(dqn, game);
        }

        static void TestGame(LearningModel.LearningModel_QLearning dqn, FindTheTreasure.FindTheTreasure game)
        {
            game.Initialize();
            do
            {
                Matrix<double> s = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                game.Move((int)dqn.GetAction(s));
                game.Visualize();
                Console.ReadKey();
                Console.Clear();
            } while (game.CheckGameValid() == true);
        }

        static void RunGame(LearningModel.LearningModel_QLearning dqn, FindTheTreasure.FindTheTreasure game)
        {
            dqn.ResetReplayBuffer();
            game.Initialize();
            do
            {
                double score = game.getStates()[2];
                Matrix<double> s = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                game.Move((int)dqn.GetAction(s));
                Matrix<double> ns = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                double r = (score - game.getStates()[2] > 8) ? 10 : -1;

                LearningModel.LearningModel_QLearning.replayData rd = new LearningModel.LearningModel_QLearning.replayData(s, new Matrix<double>(1, 1), r, ns);
                dqn.SetMemory(rd);
                dqn.Update();
                //game.Visualize();
                //Console.WriteLine("memory : {0}", dqn.GetReplayBufferCount());
            } while (game.CheckGameValid() == true);
        }
    }
}