﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


using Matrices;

namespace TwoZeroFourEightGame
{
    class Program
    {
        static void Main(string[] args)
        {
            //TwoZeroFourEight game = new TwoZeroFourEight();
            //game.StartConsoleInterfacedGame();

            //FindTheTreasure.FindTheTreasure game = new FindTheTreasure.FindTheTreasure();
            //game.StartConsoleInterfacedGame();
            LearningModel.LearningModel_QLearning dqn;

            if (File.Exists(Environment.CurrentDirectory + @"\DDQN.dat"))
            {
                dqn = Load();
            }
            else
            {
                dqn = new LearningModel.LearningModel_QLearning(new int[] { 6, 50, 1 }, new string[] { "relu", "leakyrelu", "leakyrelu" }, "MSE");
            }

            FindTheTreasure.FindTheTreasure game = new FindTheTreasure.FindTheTreasure(4, 4);

            //TestGame(dqn, game);

            int episods = 50;
            for (int i = 0; i < episods; i++)
            {
                Console.WriteLine("Episode {0}", i);
                RunGame(dqn, game);
            }

            /*Parallel.For(0, episods, (i) =>
            {
                Console.WriteLine("Episode {0}", i);
                lock (dqn)
                {
                    RunGame(dqn, game);
                }
            });*/

            Save(dqn);
            TestGame(dqn, game);
        }

        static void TestGame(LearningModel.LearningModel_QLearning dqn, FindTheTreasure.FindTheTreasure game)
        {
            game.Initialize();
            do
            {
                Matrix<double> s = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                game.Move(dqn.GetGreedyAction(s));
                game.Visualize();
                Console.ReadKey();
                Console.Clear();
            } while (game.CheckGameValid() == true);
        }

        static void RunGame(LearningModel.LearningModel_QLearning dqn, FindTheTreasure.FindTheTreasure game)
        {
            //dqn.ResetReplayBuffer();
            //dqn.ResetStepCount();
            game.Initialize();
            double totalR = 0;
            do
            {
                double score = game.getStates()[2];
                Matrix<double> s = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                int a = dqn.GetAction(s);
                game.Move(a);
                Matrix<double> ns = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                double r = (game.getStates()[2] == 10) ? 1 : -1;
                totalR += r;
                LearningModel.LearningModel_QLearning.replayData rd = new LearningModel.LearningModel_QLearning.replayData(s, ActionToMatrix(a, 4), r, ns);
                dqn.SetMemory(rd);
                dqn.Update();
                //game.Visualize();
                //Console.WriteLine("memory : {0}", dqn.GetReplayBufferCount());
            } while (game.CheckGameValid() == true);
            Console.WriteLine("total Reward : {0}", totalR);
            Console.WriteLine("epsilon : {0}", dqn.GetDecayedEpsilon());
        }

        static Matrix<double> ActionToMatrix(int action, int totalActionCount)
        {
            double[,] a = new double[1, totalActionCount];
            a[0, action] = 1;//is other indexes are set to 0 automatically?
            return new Matrix<double>(a);
        }

        static void Save(LearningModel.LearningModel_QLearning model)
        {
            Stream ws = new FileStream(Environment.CurrentDirectory + @"\DDQN.dat", FileMode.Create);
            BinaryFormatter serializer = new BinaryFormatter();
            serializer.Serialize(ws, model); // 직렬화
            ws.Close();
        }

        static LearningModel.LearningModel_QLearning Load()
        {
            Stream rs = new FileStream(Environment.CurrentDirectory + @"\DDQN.dat", FileMode.Open);
            BinaryFormatter deserializer = new BinaryFormatter();
            LearningModel.LearningModel_QLearning model = (LearningModel.LearningModel_QLearning)deserializer.Deserialize(rs); // 역 직렬화
            rs.Close();
            return model;
        }
    }
}