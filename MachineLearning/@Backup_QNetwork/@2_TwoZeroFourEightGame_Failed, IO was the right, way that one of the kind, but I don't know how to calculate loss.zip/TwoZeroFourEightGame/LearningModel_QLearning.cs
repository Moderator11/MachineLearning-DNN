﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Matrices;

namespace LearningModel
{
    class LearningModel_QLearning//https://ai.stackexchange.com/questions/10719/why-does-deep-q-network-outputs-multiple-q-values/10720#10720
    {
        int replayBufferSize = 10000;
        int batchSize = 64;
        double learningRate = 0.1;
        double discountFactor = 0.8;
        double epsilonStart = 0.9;
        public double epsilonEnd = 0.5;
        double epsilonDecay = 200;

        int stepDone = 0;
        Random actRandomness;
        Queue<replayData> replayBuffer;

        int targetNetworkUpdateCycle = 10;
        int currentCycle = 0;
        public LearningModel<double> predictNetwork;
        LearningModel<double> targetNetwork;
        int[] layerModel;

        public class replayData
        {
            public Matrix<double> state, action, nextstate;
            public double reward;

            public replayData(Matrix<double> _state, Matrix<double> _action, double _reward, Matrix<double> _nextstate)
            {
                state = _state.DeepCopy();
                action = _action.DeepCopy();
                reward = _reward;
                nextstate = _nextstate.DeepCopy();
            }
        }

        public LearningModel_QLearning(int[] _layerModel, string[] _activationFunctions, string _lossFunction)
        {
            Initialize();

            void Initialize()
            {
                stepDone = 0;
                actRandomness = new Random();
                replayBuffer = new Queue<replayData>();
                predictNetwork = new LearningModel<double>(_layerModel, _activationFunctions, _lossFunction);
                targetNetwork = new LearningModel<double>(_layerModel, _activationFunctions, _lossFunction);
                predictNetwork.Initialize_Silent();
                targetNetwork.Initialize_Silent();
                targetNetwork.biases = predictNetwork.biases;
                targetNetwork.weights = predictNetwork.weights;
                predictNetwork.learningRate = learningRate;
                targetNetwork.learningRate = learningRate;
                layerModel = _layerModel;
            }
        }

        public void SetMemory(replayData _memData)
        {
            if (replayBuffer.Count < replayBufferSize)
            {
                replayBuffer.Enqueue(_memData);
            }
            else
            {
                replayBuffer.Dequeue();
                replayBuffer.Enqueue(_memData);
            }
        }

        public double GetAction(Matrix<double> state)
        {
            int actionCount = layerModel[layerModel.Length - 1];
            double epsilonThreshold = epsilonEnd + (epsilonStart - epsilonEnd) * Math.Exp(-1 * stepDone / epsilonDecay);
            stepDone++;
            if (actRandomness.NextDouble() > epsilonThreshold)
            {
                double[,] pred = predictNetwork.GetPredict(state).GetMatrix();
                double qMax = pred[0, 0];
                int qMaxIndex = 0;
                for (int i = 1; i < layerModel[layerModel.Length - 1]; i++)
                {
                    if (qMax < pred[0, i]) { qMax = pred[0, i]; qMaxIndex = i; }
                }
                return qMaxIndex;
            }
            else
                return actRandomness.Next(0, actionCount);
        }

        public void LearnSingle(replayData replayData)
        {
            Matrix<double> a = replayData.action;
            Matrix<double> s = replayData.state;
            double r = replayData.reward;
            Matrix<double> ns = replayData.nextstate;

            TrainToUpdateQValue();
            CopyToTargetNetwork();

            void TrainToUpdateQValue()
            {
                //double[,] predict = predictNetwork.GetPredict(s).GetMatrix();
                double[,] target = targetNetwork.GetPredict(ns).GetMatrix();
                double quality_MAX = target[0, 0];
                int maxQIndex = 0;
                for (int i = 1; i < layerModel[layerModel.Length - 1]; i++)
                {
                    if (quality_MAX < target[0, i])
                    {
                        quality_MAX = target[0, i];
                        maxQIndex = i;
                    }
                }
                //predict[0, maxQIndex] = (1 - learningRate) * predict[0, maxQIndex] + learningRate * (r + discountFactor * target[0, maxQIndex]);
                Console.WriteLine();
                Matrix<double>.EnumerateMatrix(target);
                target[0, maxQIndex] = (r + discountFactor * target[0, maxQIndex]);
                Matrix<double>.EnumerateMatrix(target);
                predictNetwork.Train_Silent(s, new Matrix<double>(target));
            }

            void CopyToTargetNetwork()
            {
                if (currentCycle >= targetNetworkUpdateCycle)
                {
                    targetNetwork.biases = predictNetwork.biases;
                    targetNetwork.weights = predictNetwork.weights;
                    currentCycle = 0;
                }
                else
                {
                    currentCycle++;
                }
            }
        }

        public void Update()
        {
            if (replayBuffer.Count < batchSize) { return; }
            replayData[] buffer = replayBuffer.ToArray();
            for (int i = 0; i < batchSize; i++)
            {
                LearnSingle(buffer[actRandomness.Next(0, buffer.Length - 1)]);
            }
        }

        public int GetReplayBufferCount()
        {
            return replayBuffer.Count;
        }

        public void ResetReplayBuffer()
        {
            replayBuffer.Clear();
        }
    }
}