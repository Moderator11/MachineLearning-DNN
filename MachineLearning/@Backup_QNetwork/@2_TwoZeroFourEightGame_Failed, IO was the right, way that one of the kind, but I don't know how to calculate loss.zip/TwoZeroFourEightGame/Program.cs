﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Matrices;

namespace TwoZeroFourEightGame
{
    class Program
    {
        static void Main(string[] args)
        {
            //TwoZeroFourEight game = new TwoZeroFourEight();
            //game.StartConsoleInterfacedGame();

            //FindTheTreasure.FindTheTreasure game = new FindTheTreasure.FindTheTreasure();
            //game.StartConsoleInterfacedGame();

            LearningModel.LearningModel_QLearning dqn = new LearningModel.LearningModel_QLearning(new int[] { 2, 8,8, 4 }, new string[] { "relu", "leakyrelu", "leakyrelu", "leakyrelu" }, "MSE");

            FindTheTreasure.FindTheTreasure game = new FindTheTreasure.FindTheTreasure();

            //TestGame(dqn, game);

            int episods = 500;
            for (int i = 0; i < episods; i++)
            {
                Console.WriteLine("Episode {0}", i);
                RunGame(dqn, game);
            }

            for (; ; )
            {
                switch(Console.ReadKey().Key)
                {
                    case ConsoleKey.D1:
                        string[] i = Console.ReadLine().Split(',');
                        dqn.predictNetwork.Predict(new Matrix<double>(new double[,] { { double.Parse(i[0]), double.Parse(i[1]) } }));
                        break;
                    case ConsoleKey.D2:
                        goto N30;
                }
            }
            N30:

            dqn.epsilonEnd = 0;
            TestGame(dqn, game);
        }

        static void TestGame(LearningModel.LearningModel_QLearning dqn, FindTheTreasure.FindTheTreasure game)
        {
            game.Initialize();
            do
            {
                Matrix<double> s = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                game.Move((int)dqn.GetAction(s));
                game.Visualize();
                Console.ReadKey();
                Console.Clear();
            } while (game.CheckGameValid() == true);
        }

        static void RunGame(LearningModel.LearningModel_QLearning dqn, FindTheTreasure.FindTheTreasure game)
        {
            dqn.ResetReplayBuffer();
            game.Initialize();
            double totalR = 0;
            do
            {
                double score = game.getStates()[2];
                Matrix<double> s = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                game.Move((int)dqn.GetAction(s));
                Matrix<double> ns = new Matrix<double>(new double[,] { { game.getStates()[0], game.getStates()[1] } });
                double r = (game.getStates()[2] == 10) ? 10 : -1;
                totalR += r;
                LearningModel.LearningModel_QLearning.replayData rd = new LearningModel.LearningModel_QLearning.replayData(s, new Matrix<double>(1, 1), r, ns);
                dqn.SetMemory(rd);
                dqn.Update();
                //game.Visualize();
                //Console.WriteLine("memory : {0}", dqn.GetReplayBufferCount());
            } while (game.CheckGameValid() == true);
            Console.WriteLine("total Reward : {0}", totalR);
        }
    }
}